import bpy
import os

class USDPanel(bpy.types.Panel):
    bl_label = "USD Panel"
    bl_idname = "USD_PANEL"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'

    def draw(self, context):
        layout = self.layout
        layout.label(text="USD Layers")

        # Create a button for importing a USD file
        layout.operator("wm.usd_import")

        # Create a button for exporting a USD file
        layout.operator("wm.usd_export")

        # Create a button for creating a new USD layer
        layout.operator("usd.create_layer")

        # Create a button for deleting the active USD layer
        layout.operator("usd.delete_layer")

class CreateUSDLayersOperator(bpy.types.Operator):
    bl_idname = "usd.create_layer"
    bl_label = "Create USD Layer"

    def execute(self, context):
        try:
            # Create a new collection
            collection = bpy.data.collections.new("new_layer")
            bpy.context.scene.collection.children.link(collection)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

class DeleteUSDLayersOperator(bpy.types.Operator):
    bl_idname = "usd.delete_layer"
    bl_label = "Delete USD Layer"

    def execute(self, context):
        try:
            # Delete the active collection
            collection = bpy.context.view_layer.active_layer_collection.collection
            if collection:
                bpy.data.collections.remove(collection)
                return {'FINISHED'}
            else:
                self.report({'ERROR'}, "No active collection to delete.")
                return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

def register():
    bpy.utils.register_class(USDPanel)
    bpy.utils.register_class(CreateUSDLayersOperator)
    bpy.utils.register_class(DeleteUSDLayersOperator)

def unregister():
    bpy.utils.unregister_class(USDPanel)
    bpy.utils.unregister_class(CreateUSDLayersOperator)
    bpy.utils.unregister_class(DeleteUSDLayersOperator)

if __name__ == "__main__":
    register()